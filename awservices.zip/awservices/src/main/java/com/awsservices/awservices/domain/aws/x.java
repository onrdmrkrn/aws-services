package com.awsservices.awservices.domain.aws;

public class x {
}
