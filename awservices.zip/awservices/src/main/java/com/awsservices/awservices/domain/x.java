package com.awsservices.awservices.domain;

public class x {
}
