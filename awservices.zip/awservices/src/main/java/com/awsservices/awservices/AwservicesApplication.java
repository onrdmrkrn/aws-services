package com.awsservices.awservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwservicesApplication.class, args);
	}

}
