package com.awsservices.awservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
